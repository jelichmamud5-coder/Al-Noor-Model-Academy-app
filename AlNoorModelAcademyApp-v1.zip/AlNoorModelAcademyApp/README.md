# AL-NOOR MODEL ACADEMY — Android App v1.0

A starter Android school-management app using the supplied school logo.

## Included
- School-branded welcome screen
- Admin / Teacher / Student / Parent role selection
- Dashboard cards for Notices, Routine, Homework, Results, Attendance, Fees, Study Materials and Contact
- Portrait mobile layout

## Build
Open this project in Android Studio and choose **Build > Build APK(s)**. The project uses Android Gradle Plugin 8.6.1 and compileSdk 35.

This Version 1 is a UI/prototype foundation. Real login, database, online fees, push notifications and admin backend need to be connected in the next phase.
